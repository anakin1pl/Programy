#include <iostream>
#include <point.h>
#include <point1.h>


using namespace std;
using namespace pt;

class Polygon{
        
        
        
        
};

int main()
{
 //   Point *p1= new Point();
  //  Point p2 = Point(); 
 
  //  cout<<p1->GetX()<<endl;
  //  cout<<p1->GetX()<<endl; 
    
    Point *p1 = new Point();
    cout<<p1->GetX ();
    
    
    return 0;
}
