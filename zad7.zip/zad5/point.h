#ifndef POINT_H
#define POINT_H

namespace pt {
    

class Point{
        
    private:
        int x,y;
        
    public:
        
        Point ();
        
        int GetX() ;
        int GetY() ;
        void SetX(int x) ;
        void SetY(int y) ;
        
        
};
}

#endif // POINT_H
