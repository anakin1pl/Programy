#include "point.h"

using namespace pt;

Point::Point()
{
    this->x=0;
    this->y=0;
}

int Point::GetX(){
    return this->x;
}
int Point::GetY(){
    return this->x;
}