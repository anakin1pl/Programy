#ifndef POINT_H
#define POINT_H


namespace pt{
class Point
{
               
          private:
              int x,y;
              
          public:
                        
             Point ();              
             int GetX() ;
             int GetY() ;
                        
};
}
#endif // POINT_H
