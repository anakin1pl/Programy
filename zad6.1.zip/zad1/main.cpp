#include <iostream>
#include <fstream>

using namespace std;

class Polygon
{

        
 public:
        
    struct Point
        {
        float x;
        float y;
        };
    
    Polygon() 
        { 
        this->punkty=4;
        this->komorki=0;
        points = new Point *[10];
        points [0] = new Point();
        }
    Polygon(int liczba) 
        {
        if(liczba%4==0) this->komorki=liczba;
        else if (liczba%4==1) this->komorki=liczba+3;
        else if (liczba%4==2) this->komorki=liczba+2;
        else if (liczba%4==3) this->komorki=liczba+1;
        }
    Polygon(const Polygon &polygon) 
        {
        komorki = polygon.komorki;
        punkty  = polygon.punkty; 
        points  = new Point*[komorki];
        for(int i=0;i<komorki;i++){
            points[i]    = new Point();
            points[i]->x = polygon.points[i]->x;
            points[i]->y = polygon.points[i]->y;
            }
        }
    ~Polygon()
        {
        for(int i=0;i<punkty;i++) delete points[i];
        delete this->points;
        }
    
    
    Point** GetPoints()
        {
        return this->points;
        }
    int GetK()
        {
        return this->komorki;
        }
    int GetP()
        {
        return this->punkty;
        }
    
    void Add (Point pk)
        {
        if(komorki==punkty)
            {
            Point **tmp= points;
            punkty+=4;
            points= new Point*[punkty];
            for(int i=0;i<komorki;i++) points[i] = tmp[i];
            delete tmp;
            }
        points[komorki]  = new Point();
        *points[komorki] = pk;
        komorki++;
            
        }
    
    
    private:
           
           Point** points;
           int komorki;
           int punkty;
};

class Image {
        
    private:
        Polygon *tab[10];
        int ilosc;
        Image(const Image &img);
    public:
        
        void(FILE *fp)
        
        {
        
        
        
        
        
};

int main()
{
 Polygon *pol1= new Polygon();
 Polygon *pol3 =new Polygon();
 pol1->GetPoints()[0]->x=5;
 pol1->GetPoints()[0]->y=6;
 Polygon *pol2(pol1);
 //cout<<pol1->GetPoints()[0]->x<<endl;
 //cout<<pol1->GetPoints()[0]->y<<endl;
 cout<<pol2->GetPoints()[0]->x<<endl;
 cout<<pol2->GetPoints()[0]->y<<endl;
 
 Polygon polygon (25);
 Polygon::Point p;
 p.x=8;
 p.y=9;
 pol3->Add(p);
 cout<<pol3->GetPoints()[0]->x<<endl;
 cout<<pol3->GetPoints()[0]->y<<endl;
 
    return 0;
}
