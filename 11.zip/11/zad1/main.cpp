#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
using namespace std;


/*
template <typename Typ>
Typ mn(Typ l1, Typ l2)
{
    cout<<"Template"<<endl;
    return l1*l2;
}
*/
/*
template <typename T>
T minx(T *poczatek, T *koniec)
{
    T *x;
    for(int *i= poczatek;i<koniec;i++){
        if(i<x) x=i;
       cout<<*i<<endl;
    }
    return *x;
}
*/

template <typename Typ>
Typ mn(Typ *l1, Typ *l2)
{
    return l1*l2;
}
/*
template<>
string mn<string>(string l1, string l2)
{
    return to_string(stod(l1)*stod(l2));
}
*/
template<>
string mn<string>(string *a, string *k)
{
    sort(a->begin(), a->end());
    return a[1];
}

template<typename T>
T *t(vector<T>a){
    return &a[0];
        
}




int main()
{
    
    //cout<<mn<int>(1,2)<<endl;
    //cout<<mn<double>(2.5,4.3);
    
   // int tab[]={1,2,3,7,2,1,88,5};
   // cout<<"min:"<<minx<int>(&tab[0],&tab[7])<<endl;
   //  string tab[]={"dsac","dsdsaac","bbbs"};
   // string tab1[]={"asbc","dsac","bbbs"};
   // cout<<mn<string>(tab,tab1)<<endl;
    
    vector<int>a;
    a.push_back (7);
    
    cout<<*t<int>(a)<<endl;
    return 0;
}
