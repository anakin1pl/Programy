#include <iostream>

using namespace std;


struct vect3{
    float x,y,z;
};

vect3 operator+ (vect3 &v1, vect3 &v2){
    
    vect3 wektor;
    wektor.x=v1.x+v2.x;
    wektor.y=v1.y+v2.y;
    wektor.z=v1.z+v2.z;
    
    return wektor;
}






int main()
{
    vect3 Vector1;
    vect3 Vector2;
    
    Vector1.x=1;
    Vector1.y=2;
    Vector1.z=3;
    
    Vector2.x=4;
    Vector2.y=5;
    Vector2.z=6;
    
    cout<<(Vector1+Vector2).x <<endl;
    
    return 0;
}
