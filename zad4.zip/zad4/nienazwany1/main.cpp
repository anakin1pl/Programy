#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;



class Villager
{
    private:
        string imie;
        unsigned int wiek, max_wiek;
        bool plec;
        string ludzie[5]={"aaa","ddd","bbb","ccc","eee"};
    
    public:
        
        Villager()
        { 
        this->max_wiek=rand()%100;
        this->imie=ludzie[rand ()%5];
        this->wiek=rand()%this->max_wiek;
        this->plec=rand()%2-1;
          
        cout<<"Nowa osoba "<< this->imie<< this->wiek<< this->max_wiek<<this->plec <<endl;
        }
        
        Villager(string imie, unsigned int wiek, unsigned int max_wiek, bool plec)
        {
         this->imie=imie;
         this->wiek=wiek;
         this->max_wiek=max_wiek;
         this->plec=plec;
            
         cout<<"Nowa osoba "<< this->imie<< this->wiek<< this->max_wiek<<this->plec <<endl;
        }
        
        
        void SetImie(string imie){ this->imie=imie;}
        string GetImie(){ return imie;}
        int GetWiek()   { return wiek;}
        bool GetPlec()  { return plec;}
        
        Villager(Villager &vOrg)
        {
       // this->imie= new string;
       // *this->imie=vOrg.GetImie ();
        }
        
        void zwieksz_wiek()
        { 
            this->wiek++;
            if( this->wiek==max_wiek){delete this;}
        }
        
        ~Villager()
        {
         cout<<"smierc "<<this->imie<<endl;  
        }   
};

class Household :public Villager{
    
    private:
        Villager *tab;
        int max;
        
    public:
        
        Household(int max)
        {
            this->max=max;
        }
        
        void zwieksz_wiek()
        {
            for(int i=0;i<max;i++)
                tab[i].zwieksz_wiek ();      
        } 
        
        Villager *getTab()  { return tab; }
        
        void rozmnazanie()
        {
            int m=0,k=0,wm=0, wk=0, wd=0;
            
            for(int i=0;i<this->max;i++){
                
                    if(tab[i].GetWiek()==1 ) m=1;
                else k=1;
                    
                    if(tab[i].GetWiek()>=18 && tab[i].GetWiek()<=40 && tab[i].GetPlec()==1)  wm=1;
                else if (tab[i].GetWiek()>=18 && tab[i].GetWiek()<=40 && tab[i].GetPlec()==0) wk=1;
                    
                    if(tab[i].GetWiek()<=5) wd=1;
                    
                    
                    
                }    
                     
        
        }
        
        
};

int main()
{
    srand (time(NULL));
   // Villager Stefan;
   // Villager Stefan("stefan",10,100,true);
   //  Villager *Stefan = new Villager();
   // Villager *Bob = new Villager();
   // cout<<Stefan->GetImie ()<< endl;
   // cout<<Bob->GetImie ()<< endl;
    
    Villager *vill= new Villager("jan", 1,3, true);
   // vill->zwieksz_wiek ();

    
    
    Villager *Stefan = new Villager();
    Villager *Bob = new Villager();
    
    Household *house= new Household(5);
    house->getTab()[0]=*vill;
    house->getTab()[1]=*Stefan;
    house->getTab()[2]=*Bob;
    
    
   
    return 0;
}
