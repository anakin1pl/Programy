#include <iostream>
#include <vector>
using namespace std;



void f(int min, int max,vector <int>&x){
    auto zm=[min,max](int d){return d>min&& d<max;};
    replace_if(x.begin(),x.end(),zm,0);  
}



int main()
{
    vector <int>x;
    x.push_back (44);
    x.push_back (10);
    x.push_back (4);
    f(2,6,x);
    for(int i=0;i<x.size();i++){
        cout<<x[i]<<endl;
    }
    return 0;
}
